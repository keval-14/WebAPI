﻿namespace Project.Repository
{
    public class Class1
    {

    }
}
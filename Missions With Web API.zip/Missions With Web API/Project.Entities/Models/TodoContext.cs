﻿using Microsoft.EntityFrameworkCore;
using MissionWebApi.Models;
using Project.Entities.Models.Mission.Mission_Request_Model;
using Project.Entities.Models.Mission.Mission_Response_Model;

namespace MissionWebApi.Models
{
    public class TodoContext : DbContext
    {
        public TodoContext(DbContextOptions<TodoContext> options)
       : base(options)
        {
        }
        public DbSet<ResponseMission> Missions { get; set; } = null!;
        public DbSet<RequestMission>? MissionFilter { get; set; }

    }
}

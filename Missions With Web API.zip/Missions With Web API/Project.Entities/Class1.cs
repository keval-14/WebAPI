﻿namespace Project.Entities
{
    public class Class1
    {

    }
}